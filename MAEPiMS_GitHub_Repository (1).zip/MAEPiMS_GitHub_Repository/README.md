# MAEPiMS 2026 — Nigeria Influenza Forecasting

An original and reproducible forecasting workflow for the MAEPiMS 2.0 Nigeria Influenza Forecasting Challenge.

## Objective

Forecast seasonal influenza activity using only the supplied MAEPiMS simulated surveillance dataset. The workflow covers weekly national cases, hospitalisations and deaths; seasonal targets; North/South and state-level forecasts; and probabilistic outputs.

## Forecasting framework

**SAIP — Seasonal Analog + Intensity + Propagation**

The final full-season 2026/2027 forecast uses recent seasonal analogues and population-weighted spatial aggregation. Historical model evaluation also tests Random Forest, XGBoost and their ensemble against a seasonal baseline.

## Main tasks covered

- National weekly cases
- Weekly hospitalisations
- Weekly deaths
- Peak week and peak incidence
- Seasonal cumulative burden
- Seasonal attack rate
- North and South forecasts
- All 36 states + FCT
- Median and probabilistic forecasts
- 50% and 90% prediction intervals
- Historical validation and model comparison
- WIS, approximate CRPS, quantile loss and coverage diagnostics

## Repository structure

```text
MAEPiMS_GitHub_Repository/
├── README.md
├── requirements.txt
├── .gitignore
├── notebooks/
│   └── MAEPiMS_2026_Final_Short_Human.ipynb
├── src/
│   └── maepims_forecasting.py
├── outputs/
│   ├── MAEPiMS_results.xlsx
│   ├── MAEPiMS_national_probabilistic_final.csv
│   ├── MAEPiMS_regional_long_final.csv
│   ├── MAEPiMS_state_cases_probabilistic_final.csv
│   ├── tables/
│   └── figures/
└── report/
    └── MAEPiMS_2026_Nigeria_Influenza_Forecasting_Report.pdf
```

## Reproducibility

1. Obtain the challenge dataset from the official MAEPiMS source.
2. Open the notebook in Google Colab.
3. Install dependencies from `requirements.txt`.
4. Run the notebook from top to bottom.
5. The notebook produces the forecast tables and figures used in the report.

The supplied challenge dataset should not be committed to this repository unless the organisers explicitly permit redistribution.

## Validation

Historical validation is performed on held-out seasons. The repository separates validation results from 2026/2027 future forecasts; future accuracy cannot be known until observations for that season are available.

## Key historical case-model result

The previously tested selected ensemble used:

**20% seasonal + 20% Random Forest + 60% XGBoost**

Reference validation result from the earlier model-testing run:

- MAE: **38.466**
- RMSE: **74.215**
- Peak-week error: **1 week**
- Peak-incidence error: **1.45%**
- Cumulative-case error: **8.14%**

These figures are historical validation results, not future 2026/2027 accuracy claims.

## Report

The technical report is included in `report/`.

## GitHub repository link

Add the final GitHub repository URL here before submitting the PDF to MAEPiMS.

## Citation

MAEPiMS Challenge 2026. Nigeria Influenza Forecasting Challenge. Supplied simulated national surveillance dataset and challenge brief.
